/**
 * A class to implement a non-personalised recommender model
 */

package rec.np;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import rec.dataset.Dataset;
import rec.np.ranker.Ranker;
import rec.util.Matrix;
import rec.util.Pair;

public class NPRecommender {
	private static final double EPSILON = 1e-10;

	private Dataset dataset; // Dataset object
	private Ranker ranker; // the ranker used to rank items
	private Matrix scores; // used to store all item-item rank scores

	/**
	 * constructor - creates a new NPRecommender object
	 * @param dataset - Dataset object
	 * @param ranker - the ranker used to rank items
	 */
	public NPRecommender(Dataset dataset, Ranker ranker) {
		this.dataset = dataset;
		this.ranker = ranker;
		scores = new Matrix();
	}

	/**
	 * Returns the recommendations for the target item
	 * @param targetItemId - the target item id
	 * @returns an ArrayList object containing the recommended item ids for the target item
	 */
	public List<Integer> recommend(int targetItemId) {	
		// get ids of recommendation candidates for the target item
		Set<Integer> ids = scores.getColIds(targetItemId); 

		// return an empty ArrayList object if there are no recommendation candidates for the 
		// target item
		if (ids == null)
			return new ArrayList<>();
		else {
			// for each recommendation candidate:
			// - get the rank score
			// - create a Pair object - containing the candidate's id and rank score 
			// - add the Pair object to a list
			List<Pair> candidates = new ArrayList<>(); 
			for (int id: ids) {
				double score = scores.getValue(targetItemId, id); // get rank score for id
				candidates.add(new Pair(id, score)); // add Pair object to the list
			}

			// sort the list of Pair objects by rank score - note objects are sorted in 
			// *ascending* order 
			Collections.sort(candidates);
			
			// return a list containing ids sorted in *descending* order by rank score
			List<Integer> recIds = new ArrayList<>();
			for (int i = candidates.size() - 1; i >= 0; i--)
				recIds.add(candidates.get(i).getValue());
			return recIds;
		}
	}

	/**
	 * For each item, computes the rank scores of all other items. Rank scores are stored
	 * in the Matrix object scores, such that, for a given item X, the rank score of item 
	 * Y is stored in element x, y (where x and y are the ids of items X and Y, respectively).
	 */
	public void fit() {
		// get the set of item ids
		Set<Integer> itemIds = dataset.getItemIds();

		// for each item, compute the rank scores of all other items
		for(int id1: itemIds) {			
			for(int id2: itemIds) {
				if(id2 < id1) {
					if(ranker instanceof rec.np.ranker.GenreJaccardRanker ||
							ranker instanceof rec.np.ranker.GenomeCosineRanker ||
							ranker instanceof rec.np.ranker.RatingPearsonRanker) { // rank scores are symmetric
						double score = ranker.getRankScore(dataset.getItem(id1), dataset.getItem(id2));
						if (score > EPSILON) { // add rank score if greater than EPSILON (EPSILON used in place of 0 to handle rounding errors)
							scores.addValue(id1, id2, score);
							scores.addValue(id2, id1, score);
						}
					} else if (ranker instanceof rec.np.ranker.PopularityRanker) { // rank scores are not symmetric
						double score = ranker.getRankScore(dataset.getItem(id1), dataset.getItem(id2));
						if(score > EPSILON)
							scores.addValue(id1, id2, score);

						score = ranker.getRankScore(dataset.getItem(id2), dataset.getItem(id1));
						if(score > EPSILON) 
							scores.addValue(id2, id1, score);				
					} else if (ranker instanceof rec.np.ranker.IncConfidenceRanker) { // rank scores are not symmetric
						double score = ranker.getRankScore(dataset.getItem(id1), dataset.getItem(id2));
						if(score > 1)
							scores.addValue(id1, id2, score);

						score = ranker.getRankScore(dataset.getItem(id2), dataset.getItem(id1));
						if(score > 1) 
							scores.addValue(id2, id1, score);
					} else {
						System.out.println("Error - invalid ranker");
						System.exit(1);
					}
				}
			}
		}
	}
}
