/**
 * A class to evaluate a non-personalised recommender model
 */

package rec.np.evaluator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import rec.dataset.Dataset;
import rec.np.NPRecommender;
import rec.util.Matrix;

public class NPEvaluator {
	private static final double EPSILON = 1e-10;

	private NPRecommender model; // non-personalised recommender model
	private Dataset dataset; // a Dataset object
	private int k; // the number of recommendations to be made
	private double threshold; // an item is considered liked if its rating is >= threshold
	private Map<Integer,List<Integer>> recsMap; // stores the recommendations made for each item
	private Matrix simMatrix; // used to store all item-item similarity scores

	/**
	 * constructor - creates a new object
	 * @param model - the non-personalised recommender model
	 * @param dataset - a Dataset object
	 * @param k - the number of recommendations to be made
	 * @param threshold - an item is considered liked if its rating is >= threshold
	 */
	public NPEvaluator(NPRecommender model, Dataset dataset, int k, double threshold) {
		this.model = model;
		this.dataset = dataset;
		this.k = k;
		this.threshold = threshold;
		recsMap = new HashMap<Integer,List<Integer>>();

		// make recommendations for each item
		Set<Integer> itemIds = dataset.getItemIds();
		for (int itemId: itemIds) {
			List<Integer> recs = model.recommend(itemId);
			recsMap.put(itemId, recs);
		}

		// calculate item-item similarities based on genome tag scores
		calculateItemSimilarities();
	}

	/**
	 * @return the coverage which is given by the percentage of target 
	 * items for which at least one recommendation can be made
	 */
	public double getCoverage() {
		int nitems = 0;

		Set<Integer> itemIds = dataset.getItemIds();
		for (int itemId: itemIds) {
			List<Integer> recs = recsMap.get(itemId);
			if (recs.size() > 0) 
				nitems++;
		}

		return (itemIds.size() > 0) ? nitems * 1.0 / itemIds.size() : 0;
	}

	/**
	 * @return the percentage of movies in the dataset which appear at 
	 * least once in the top-k recommendations made over all target items
	 */
	public double getRecommendationCoverage() {
		Set<Integer> allRecs = new HashSet<Integer>();

		Set<Integer> itemIds = dataset.getItemIds();
		for (int itemId: itemIds) {
			List<Integer> recs = recsMap.get(itemId);
			for (int i = 0; i < recs.size() && i < k; i++)
				allRecs.add(recs.get(i));
		}

		return (itemIds.size() > 0) ? allRecs.size() * 1.0 / itemIds.size() : 0;
	}

	/**
	 * For a given target item, the percentage of items in the system
	 * which are capable of being recommended (i.e. those items which
	 * which have a similarity greater than 0 with the target items).
	 * The value returned is the average percentage over all target items.
	 */
	public double getItemSpaceCoverage() {
		double meanCoverage = 0;
		int nitems = 0;

		Set<Integer> itemIds = dataset.getItemIds();
		for (int itemId: itemIds) {
			List<Integer> recs = recsMap.get(itemId);
			if (recs.size() > 0) {
				meanCoverage += (itemIds.size() - 1 > 0) ? recs.size() * 1.0 / (itemIds.size() - 1) : 0;
				nitems++;
			}
		}

		return (nitems > 0) ? meanCoverage / nitems : 0;
	}

	/**
	 * For a given target item, the cardinality of the union of genres 
	 * associated with each of the top-k recommended items is divided
	 * by the total number of genres in the dataset. 
	 * The value returned is the average (normalised) cardinality over all 
	 * target items.
	 */
	public double getCategoryCoverage() {
		double coverage = 0;
		int nitems = 0;

		Set<Integer> itemIds = dataset.getItemIds();
		for (int itemId: itemIds) {
			Set<String> union = new HashSet<>();

			List<Integer> recs = recsMap.get(itemId);
			if (recs.size() > 0) {
				for (int i = 0; i < recs.size() && i < k; i++)
					union.addAll(dataset.getItem(recs.get(i)).getGenres());

				coverage += 1.0 * union.size() / dataset.getDatasetGenres().size();
				nitems++;
			}
		}

		return (nitems > 0) ? coverage / nitems : 0;
	}

	/**
	 * The popularity of a recommended movie is given by the percentage 
	 * of users in the system which have rated the movie.
	 * For a given target movie, the popularity of the top-k recommendations 
	 * made is calculated by taking the average of the popularity over each 
	 * recommended movie. 
	 * The value returned is the average popularity over all target movies.
	 */
	public double getRecommendationPopularity() {
		double meanPopularity = 0;
		int nitems = 0;

		Set<Integer> itemIds = dataset.getItemIds();
		for (int itemId: itemIds) {
			double popularity = 0;
			int counter = 0;
			List<Integer> recs = recsMap.get(itemId);
			for (int i = 0; i < recs.size() && i < k; i++) {
				popularity += dataset.getItem(recs.get(i)).getTrainRatings().size() * 1.0 / dataset.getUserIds().size();
				counter++;
			}

			if (counter > 0) {
				meanPopularity += popularity / counter;
				nitems++;
			}
		}

		return (nitems > 0) ? meanPopularity / nitems : 0;
	}

	/**
	 * The relevance of a recommended movie is given by the mean of 
	 * the ratings the item received in the training set.
	 * For a given target item, the relevance of the top-k recommendations 
	 * made is calculated by taking the average of the mean rating over each 
	 * recommended item. 
	 * The value returned is the average relevance over all target items.
	 */
	public double getRecommendationRelevance() {
		double meanRelevance = 0;
		int nitems = 0;

		Set<Integer> itemIds = dataset.getItemIds();
		for (int itemId: itemIds) {
			double relevance = 0;
			int counter = 0;
			List<Integer> recs = recsMap.get(itemId);
			for (int i = 0; i < recs.size() && i < k; i++) {
				relevance += getMeanValue(dataset.getItem(recs.get(i)).getTrainRatings());
				counter++;
			}

			if (counter > 0) {
				meanRelevance += relevance / counter;
				nitems++;
			}
		}

		return (nitems > 0) ? meanRelevance / nitems : 0;
	}

	/**
	 * The relevance of a recommended movie based on the ratings the item 
	 * received in the training set (using lower bound of 95% CI).
	 * For a given target item, the relevance of the top-k recommendations 
	 * made is calculated by taking the average of the relevance over each 
	 * recommended item. 
	 * The value returned is the average relevance over all target items.
	 */
	public double getRecommendationRelevance95() {
		double meanRelevance = 0;
		int nitems = 0;

		Set<Integer> itemIds = dataset.getItemIds();
		for (int itemId: itemIds) {
			double relevance = 0;
			int counter = 0;
			List<Integer> recs = recsMap.get(itemId);
			for (int i = 0; i < recs.size() && i < k; i++) {
				Map<Integer,Double> map = dataset.getItem(recs.get(i)).getTrainRatings();
				int npos = 0;
				for (Integer id: map.keySet())
					if (map.get(id) >= threshold)
						npos++;
				relevance += lowerBound95(npos, map.size());
				counter++;
			}

			if (counter > 0) {
				meanRelevance += relevance / counter;
				nitems++;
			}
		}

		return (nitems > 0) ? meanRelevance / nitems : 0;
	}

	/**
	 * For a given target item, the similarity of the top-k recommendations 
	 * made is calculated by taking the average of pairwise similarities 
	 * between the target item and each of the recommended items. 
	 * The value returned is the average similarity over all target items.
	 */
	public double getRecommendationSimilarity() {
		double meanSimilarity = 0;
		int nitems = 0;

		Set<Integer> itemIds = dataset.getItemIds();
		for (int itemId: itemIds) {
			double similarity = 0;
			int counter = 0;
			List<Integer> recs = recsMap.get(itemId);
			for (int i = 0; i < recs.size() && i < k; i++) {
				similarity += simMatrix.getValue(itemId, recs.get(i));
				counter++;
			}

			if (counter > 0) {
				meanSimilarity += similarity / counter;
				nitems++;
			}
		}

		return (nitems > 0) ? meanSimilarity / nitems : 0;
	}

	/**
	 * @return the median and IQR of all (greater than zero) pairwise
	 * item similarities
	 */
	public double[] getItemSimilarityStats() {
		// get the set of item ids
		Set<Integer> itemIds = dataset.getItemIds();

		// add (greater than zero) pairwise item similarities to a list
		List<Double> vals = new ArrayList<>();

		for(Integer id1: itemIds) {			
			for(Integer id2: itemIds) {
				if(id2 < id1) {
					double sim = simMatrix.getValue(id1, id2);
					if (sim > EPSILON)  // check if similarity is greater than EPSILON (EPSILON used in place of 0 to handle rounding errors)
						vals.add(sim);
				}
			}
		}

		// return the median and IQR
		return new double[]{getMedian(vals), getIQR(vals)};
	}

	/**
	 * @return the median and IQR of mean item ratings
	 */
	public double[] getItemRatingStats() {
		// get the set of item ids
		Set<Integer> itemIds = dataset.getItemIds();

		// add the mean of the ratings assigned to each item to a list
		List<Double> vals = new ArrayList<>();
		for (int id: itemIds)
			vals.add(getMeanValue(dataset.getItemTrainRatings(id)));

		// return the median and IQR
		return new double[]{getMedian(vals), getIQR(vals)};
	}

	/**
	 * @return the median and IQR of item popularity
	 */
	public double[] getItemPopularityStats() {
		// get the set of item ids
		Set<Integer> itemIds = dataset.getItemIds();

		// add the popularity of each item to a list
		List<Double> vals = new ArrayList<>();
		for (int id: itemIds)
			vals.add(dataset.getItem(id).getTrainRatings().size() * 1.0 / dataset.getUserIds().size());

		// return the median and IQR
		return new double[]{getMedian(vals), getIQR(vals)};
	}

	/**
	 * Prints to standard output the top-k recommendations made for an item
	 * @param item - the target item id
	 */
	public void printRecs(int itemId) {
		System.out.println("Title: " + dataset.getItem(itemId).getTitle());
		List<Integer> recs = model.recommend(itemId);
		for (int i = 0; i < recs.size() && i < k; i++)
			System.out.println("\tRec " + (i + 1) + ": " + dataset.getItem(recs.get(i)).getTitle());
		System.out.println();
	}

	/**
	 * @param m1 - first recommender model
	 * @param m2 - second recommender model
	 * @return the number of common recommendations made by models m1 and m2 (averaged over all target items)
	 */
	public double getNumberCommonRecs(NPRecommender m1, NPRecommender m2) {
		int sumCommon = 0;

		Set<Integer> itemIds = dataset.getItemIds();
		for (int itemId: itemIds) {
			List<Integer> recs1 = m1.recommend(itemId);
			List<Integer> recs2 = m2.recommend(itemId);

			int count = 0;
			for (int i = 0; i < recs1.size() && i < k; i++)
				for (int j = 0; j < recs2.size() && j < k; j++)
					if (recs1.get(i) == recs2.get(j)) {
						count++;
						break;
					}

			sumCommon += count;
		}

		return (itemIds.size() > 0) ? sumCommon * 1.0 / itemIds.size() : 0;
	}

	/**
	 * calculates the relevance of an item
	 * @param npos - the number of positive ratings an item has received
	 * @param n - the total number of ratings an item has received
	 * @return - item relevance using lower bound of 95% CI
	 */
	private double lowerBound95(int npos, int n) {
		if (n <= 0) return 0.0;

		double z = 1.96; // 95% confidence
		double phat = 1.0 * npos / n;
		return (phat + z*z/(2*n) - z * Math.sqrt((phat*(1-phat)+z*z/(4*n))/n))/(1+z*z/n);
	}

	/**
	 * calculates the pairwise similarities between items based on genome tag scores using 
	 * cosine similarity
	 */
	private void calculateItemSimilarities() {
		simMatrix = new Matrix();

		// get the set of item ids
		Set<Integer> itemIds = dataset.getItemIds();

		// calculate the pairwise item similarities
		for(Integer id1: itemIds) {			
			for(Integer id2: itemIds) {
				if(id2 < id1) {
					// get the genome scores vectors for both items
					double[] scoresX = dataset.getItem(id1).getGenomeScores();
					double[] scoresY = dataset.getItem(id2).getGenomeScores(); 		

					// iterate over the arrays and compute the dot product and norms
					double dotProduct = 0;
					double normX = 0;
					double normY = 0;
					for(int i = 0; i < scoresX.length; i++) {
						// update the numerator and denominator
						dotProduct += scoresX[i] * scoresY[i];
						normX += Math.pow(scoresX[i], 2);
						normY += Math.pow(scoresY[i], 2);
					}

					double denom = Math.sqrt(normX * normY);

					// compute the similarity - if division by zero occurs, set to zero
					double sim = (denom > 0) ? dotProduct / denom : 0;
					if (sim > EPSILON) { // add similarity if greater than EPSILON (EPSILON used in place of 0 to handle rounding errors)
						simMatrix.addValue(id1, id2, sim);
						simMatrix.addValue(id2, id1, sim);
					}
				}
			}
		}
	}

	/**
	 * @param list - a list containing double values
	 * @return the interquartile range (IQR) of the values in the list
	 */
	public static double getIQR(List<Double> list) {
		if (list == null || list.isEmpty()) {
			throw new IllegalArgumentException("The list cannot be null or empty.");
		}

		// split the list into lower and upper halves
		ArrayList<Double> lowerHalf = new ArrayList<>();
		ArrayList<Double> upperHalf = new ArrayList<>();
		int size = list.size();
		int mid = size / 2;

		Collections.sort(list); // sort the list before splitting

		if (size % 2 == 0) {
			// even size: split into two equal halves
			lowerHalf.addAll(list.subList(0, mid));
			upperHalf.addAll(list.subList(mid, size));
		} else {
			// odd size: exclude the median from the halves
			lowerHalf.addAll(list.subList(0, mid));
			upperHalf.addAll(list.subList(mid + 1, size));
		}

		// calculate Q1 (median of lower half) and Q3 (median of upper half)
		double q1 = getMedian(lowerHalf);
		double q3 = getMedian(upperHalf);

		// calculate and return the IQR
		return q3 - q1;
	}

	/**
	 * @param list - a list containing double values
	 * @return the median of the values in the list
	 */
	public static double getMedian(List<Double> list) {
		// sort the list
		Collections.sort(list);

		int size = list.size();
		if (size % 2 == 0) {
			// even size
			return (list.get(size / 2 - 1) + list.get(size / 2)) / 2.0;
		} else {
			// odd size
			return list.get(size / 2);
		}
	}
	
	/**
	 * @param list - a map containing double values
	 * @return the mean of the values in the map
	 */
	public static double getMeanValue(Map<Integer,Double> map) {
		double sum = 0;
		for (double v: map.values())
			sum += v;
		
		return (map.size() > 0) ? sum / map.size() : 0;
	}
}
