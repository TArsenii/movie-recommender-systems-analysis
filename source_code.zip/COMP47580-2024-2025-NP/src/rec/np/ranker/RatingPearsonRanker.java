/**
 * Compute the rank score between two items based on item ratings
 */ 

package rec.np.ranker;

import rec.dataset.Item;
import java.util.Set;
import java.util.Map;
import java.util.HashSet;

public class RatingPearsonRanker implements Ranker {
    /**
     * constructor - creates a new object
     */
    public RatingPearsonRanker() {
    }

    /**
     * given item X, computes the rank score of item Y
     * @param X - the first item 
     * @param Y - the second item
     * @return the rank score for item Y
     */
    @Override
    public double getRankScore(Item X, Item Y) {
        
        // get ratings from users for x and y
        Map<Integer, Double> ratingX = X.getTrainRatings();
        Map<Integer, Double> ratingY = Y.getTrainRatings();
        
        //users - users, marked both films
        Set<Integer> users = new HashSet<>(ratingX.keySet());
        users.retainAll(ratingY.keySet());
        
        int n = users.size();
        if (n == 0) {
            return 0;
        }
        
        
        //algebra
        
        double sumX = 0.0;
        double sumY = 0.0;
        double sumXY = 0.0;
        double sumX2 = 0.0;
        double sumY2 = 0.0;
        
        
        for (int userId : users) {
            double rx = ratingX.get(userId);
            double ry = ratingY.get(userId);
            
            sumX += rx;
            sumY += ry;
            sumXY += rx * ry;
            sumX2 += rx * rx;
            sumY2 += ry * ry; 
            
        }
        
        double numenator = n * sumXY - (sumX * sumY);
        double denominator1 = n * sumX2 - (sumX * sumX);
        double denominator2 = n * sumY2 - (sumY * sumY);
        
        
        // zero division condition:
        double denom = denominator1 * denominator2;
        if (denom <= 0) {
            return 0.0;
        }
        double corr = numenator / Math.sqrt(denom);
        // applying significance weighting:
        int nx = ratingX.size();
        int ny = ratingY.size();
        
        // Corrected significance weighting formula:
        double weights = (double) n / (nx + ny - n); 
        
        // condition for division by zero
        if (nx + ny - n == 0) {
            weights = 0;
        }
        
        double score = corr * weights; 
        // compute the rank score using Pearson Correlation

        return score;
    }
}