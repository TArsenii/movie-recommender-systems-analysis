/**
 * Compute the rank score between two items based on the increase in liking Y if X is liked
 */ 

package rec.np.ranker;

import rec.dataset.Item;
import java.util.Map;



public class IncConfidenceRanker implements Ranker {
	private double threshold; // an item is considered liked if its rating is >= threshold

	/**
	 * constructor - creates a new object
	 * @param threshold - the threshold for liked items
	 */
	public IncConfidenceRanker(double threshold) {
		this.threshold = threshold;
	}

	/**
	 * given item X, computes the rank score of item Y
	 * @param X - the first item 
	 * @param Y - the second item
	 * @return the rank score for item Y 
	 */
	@Override
	public double getRankScore(Item X, Item Y) {
		// compute the rank score using conf(X => Y) / conf(!X => Y)
		
		Map<Integer, Double> ratingX = X.getTrainRatings();
		Map<Integer, Double> ratingY = Y.getTrainRatings();
		
		//compute supp(x) and supp (X and Y)
		
		int countX = 0;
		int countXandY = 0; 
		// now compute supp(!X) and (!X and Y)
		int countNotX = 0; 
		int countNotXandY = 0;
		
		// loop for computing 
		for (Map.Entry<Integer, Double> entry : ratingX.entrySet()) {
			int userId = entry.getKey();
			double rx = entry.getValue();
			
			if (rx >= threshold) {
				// group if user likes X film
				countX ++;
				// checking if he likes movie Y
				if (ratingY.containsKey(userId) && ratingY.get(userId)>= threshold) {
					countXandY++;
				}
			} else {
				// way for users dont like X
				countNotX ++; 
				// if user likes Y?
				if (ratingY.containsKey(userId) && ratingY.get(userId) >= threshold) {
					countNotXandY ++;
				}
			}
		}
		
		double confX_Y = 0.0;
		if (countX > 0) {
			confX_Y = (double) countXandY / countX; 
		}
		double confNotX_Y = 0.0;
		if (countNotX > 0) {
			confNotX_Y = (double) countNotXandY / countNotX;
		}
		// zero condition
		if (confNotX_Y == 0.0) {
				return 0;
		}

		return confX_Y / confNotX_Y;
	}
}
