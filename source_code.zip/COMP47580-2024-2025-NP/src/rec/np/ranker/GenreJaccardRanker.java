/**
 * Compute the rank score between two items based on item genres
 */

package rec.np.ranker;

import rec.dataset.Item;
import java.util.HashSet;
import java.util.Set;


public class GenreJaccardRanker implements Ranker {	
	/**
	 * constructor - creates a new object
	 */
	public GenreJaccardRanker() {
	}
	
	/**
	 * given item X, computes the rank score of item Y
	 * @param X - the first item 
	 * @param Y - the second item
	 * @return the rank score for item Y
	 */
	@Override
	public double getRankScore(Item X, Item  Y) {
		// lets take union of genres for each Item
		// and put them to Ux and Uy (u - union)
		
		Set<String> uX = X.getGenres(); 
		Set<String> uY = Y.getGenres();
		
		
		//creating new parametrs to keep a copy of unions
		
		Set<String> intersection = new HashSet<>(uX);
		Set<String> union = new HashSet<>(uX);
		
		// for intersection:
		intersection.retainAll(uY);
		// for union
		union.addAll(uY);
		
		// zero division check
		
		if (union.size() == 0) {
			return 0;
		}
		
		
		// compute the rank score using Jaccard index
		
		return (double) intersection.size() / union.size();
	}
}
