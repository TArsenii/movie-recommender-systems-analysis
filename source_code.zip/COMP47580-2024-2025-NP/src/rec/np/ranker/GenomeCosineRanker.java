/**
 * Compute the rank score between two items based on item genome tag scores
 */ 

package rec.np.ranker;

import rec.dataset.Item;

public class GenomeCosineRanker implements Ranker {	
	/**
	 * constructor - creates a new object
	 */
	public GenomeCosineRanker() {
	}
	
	/**
	 * given item X, computes the rank score of item Y
	 * @param X - the first item 
	 * @param Y - the second item
	 * @return the rank score for item Y
	 */
	@Override
	public double getRankScore(Item X, Item Y) {
		// compute the rank score using Cosine
		
		// get the genome scores vectors for items X and Y
		double[] scoresX = X.getGenomeScores();
		double[] scoresY = Y.getGenomeScores(); 		
		
		// iterate over the arrays and compute the dot product and norms
		double dotProduct = 0;
		double normX = 0;
		double normY = 0;
		for(int i = 0; i < scoresX.length; i++) {
			// update the numerator and denominator
			dotProduct += scoresX[i] * scoresY[i];
			normX += Math.pow(scoresX[i], 2);
			normY += Math.pow(scoresY[i], 2);
		}
		
		double denom = Math.sqrt(normX * normY);
		
		// compute and return the rank score - if division by zero occurs, return zero
		return (denom > 0) ? dotProduct / denom : 0;
	}
}
