/**
 * Compute the rank score between two items based on the popularity of item Y
 */

package rec.np.ranker;

import rec.dataset.Item;

public class PopularityRanker implements Ranker {	
	/**
	 * constructor - creates a new object
	 */
	public PopularityRanker() {
	}
	
	/**
	 * given item X, computes the rank score of item Y
	 * @param X - the first item 
	 * @param Y - the second item
	 * @return the rank score for item Y
	 */
	@Override
	public double getRankScore(Item X, Item Y) {
		// compute the rank score based on the popularity of item Y
		
		return Y.getTrainRatings().size();
	}
}
