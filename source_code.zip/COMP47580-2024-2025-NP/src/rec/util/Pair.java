/**
 * Used as a way to order a collection of integer values, each of which is associated 
 * with some kind of score, and then inspect the collection of values ordered by the scores.
 * Note: sorts in ASCENDING order.
 */

package rec.util;

import java.util.Random;

public class Pair implements Comparable<Pair> {
	private static final double EPSILON = 1e-10;
	
	private int value;
	private double score;

	/**
	 * constructor - creates a new Pair object
	 * @param value - an integer value
	 * @param score - a double value; used to determine the natural ordering 
	 */
	public Pair(int value, double score) {
		this.value = value;
		this.score = score;
	}
	
	/**
	 * @return the value
	 */
	public int getValue() {
		return value;
	}
	
	/**
	 * @return the score
	 */
	public double getScore() {
		return score;
	}
	
	/**
	 * Returns a string representation of this object
	 */
	@Override
	public String toString() {
		return "[" + value + ", " + score + "]";
	}

	/**
	 * Used to sort Pair objects in ASCENDING order by score. Tied scores are broken randomly.
	 * @param other - the Pair object to compare to
	 * @return a negative or a positive integer if this object is less than or greater than the 
	 * specified object.
	 */
	@Override
	public int compareTo(Pair o) {
		if(Math.abs(score - o.score) < EPSILON) { // scores are equal - break ties randomly
			int s1 = 0, s2 = 1;
			if (value > o.value) { s1 = 1; s2 = 0; }
			return (new Random(s1)).nextDouble() < (new Random(s2)).nextDouble() ? -1 : +1;
		} else
			return (score < o.score) ? -1 : +1;
	}
}
