package rec.dataset;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.StringTokenizer;
import java.util.TreeSet;

import rec.util.Matrix;

public class Reader {
	private Dataset dataset; // a Dataset object containing all data used in this project

	/** 
	 * Constructs a Reader object using the MovieLens Tag Genome Dataset 2021 dataset
	 * (https://grouplens.org/datasets/movielens/tag-genome-2021).
	 * @param itemFile - the path and filename of the file containing item data
	 * @param itemGenomeScoresFile - the path and filename of the file containing item genome scores
	 * @param trainFile - the path and filename of the file containing training set ratings
	 * @param validationFile - the path and filename of the file containing validation set ratings
	 * @param testFile - the path and filename of the file containing test set ratings
	 */
	public Reader(String itemFile, String itemGenomeScoresFile, 
			String trainFile, String validationFile, String testFile) {
		Matrix userTrainRatings = readUserRatings(trainFile);
		Matrix userValidationRatings = readUserRatings(validationFile);
		Matrix userTestRatings = readUserRatings(testFile);
		Matrix itemTrainRatings = readItemRatings(trainFile);
		Map<Integer,Item> items = readItems(itemFile, itemGenomeScoresFile, itemTrainRatings);
		dataset = new Dataset(userTrainRatings, userValidationRatings, userTestRatings,
				itemTrainRatings, items);
	}

	/**
	 * @return a Dataset object
	 */
	public Dataset getDataset() {
		return dataset;
	}
	
	/**
	 * Reads the ratings for all users from a file.
	 * @param filename - the path and filename of the file containing the ratings
	 * @return a Matrix containing the ratings for all users
	 */
	private Matrix readUserRatings(String filename) {
		Matrix m = new Matrix();

		try {
			BufferedReader br = new BufferedReader(new FileReader(new File(filename)));
			br.readLine(); // read header line

			String line;
			while ((line = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line, ",");
				if(st.countTokens() != 3) {
					System.out.println("Error reading from file: " + filename);
					System.exit(1);
				}

				int userId = Integer.parseInt(st.nextToken());
				int itemId = Integer.parseInt(st.nextToken());
				double rating = Double.parseDouble(st.nextToken());

				// add data to the matrix
				m.addValue(userId, itemId, rating);
			}

			br.close();
		} catch(IOException e) {
			e.printStackTrace();
			System.exit(0);
		}

		return m;
	}

	/**
	 * Reads the ratings for all items from a file.
	 * @param filename - the path and filename of the file containing the ratings
	 * @return a Matrix containing the ratings for all items
	 */
	private Matrix readItemRatings(String filename) {
		Matrix m = new Matrix();

		try {
			BufferedReader br = new BufferedReader(new FileReader(new File(filename)));
			br.readLine(); // read header line

			String line;
			while ((line = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line, ",");
				if(st.countTokens() != 3) {
					System.out.println("Error reading from file: " + filename);
					System.exit(1);
				}

				int userId = Integer.parseInt(st.nextToken());
				int itemId = Integer.parseInt(st.nextToken());
				double rating = Double.parseDouble(st.nextToken());

				// add data to the matrix
				m.addValue(itemId, userId, rating);
			}

			br.close();
		} catch(IOException e) {
			e.printStackTrace();
			System.exit(0);
		}

		return m;
	}
	
	/**
	 * Reads the data for all items.
	 * @param itemFile - the path and filename of the file containing item data
	 * @param itemGenomeScoresFile - the path and filename of the file containing item genome scores
	 * @param itemTrainRatings - the training set ratings for all items
	 * @return a HashMap containing items
	 */
	private Map<Integer,Item> readItems(String itemFile, String itemGenomeScoresFile, 
			Matrix itemTrainRatings) {
		Matrix genomeScores = readGenomeScores(itemGenomeScoresFile);
		
		Map<Integer,Item> items = new HashMap<>();
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File(itemFile)));
			br.readLine(); // read header line
			
			String line;
			while ((line = br.readLine()) != null) {
				// read data for the current movie
				StringTokenizer st = new StringTokenizer(line, "|");
				if (st.countTokens() != 7) {
					System.out.println("Error reading from: " + itemFile);
					System.exit(1);
				}

				int itemId = Integer.parseInt(st.nextToken().trim());
				String title = st.nextToken().trim();
				int year = Integer.parseInt(st.nextToken().trim());
				Set<String> directors = toSet(st.nextToken().trim());
				Set<String> stars = toSet(st.nextToken().trim());
				String imdbId = st.nextToken().trim();
				Set<String> genres = toSet(st.nextToken().trim());
				
				// check if the current movie's genome scores and training ratings are available
				if (genomeScores.getRow(itemId) == null) {
					System.out.println("Error no genome scores for item");
					System.exit(1);
				}
				
				if (itemTrainRatings.getRow(itemId) == null) {
					System.out.println("Error no training set ratings for item");
					System.exit(1);
				}
				
				// create a new Item object and add it to the map
				Item item = new Item(itemId, title, year, directors, stars, imdbId, genres,
						toArray(genomeScores.getRow(itemId)), itemTrainRatings.getRow(itemId));
				items.put(itemId, item);
			}

			br.close();
		} catch(IOException e) {
			e.printStackTrace();
			System.exit(0);
		}
		
		return items;
	}
	
	/**
	 * Reads the genome scores for all items.
	 * @param itemGenomeScoresFile - the path and filename of the file containing item genome scores
	 * @return a Matrix containing item genome scores
	 */
	private Matrix readGenomeScores(String itemGenomeScoresFile) {
		Matrix m = new Matrix();
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File(itemGenomeScoresFile)));
			br.readLine(); // read header line
			
			String line;
			while ((line = br.readLine()) != null) {
				// read data
				StringTokenizer st = new StringTokenizer(line, ",");
				if (st.countTokens() != 4) {
					System.out.println("Error reading from: " + itemGenomeScoresFile);
					System.exit(1);
				}

				int itemId = Integer.parseInt(st.nextToken());
				int tagId = Integer.parseInt(st.nextToken());
				st.nextToken(); // for the tag
				double score = Double.parseDouble(st.nextToken());
				
				m.addValue(itemId, tagId, score);
			}

			br.close();
		} catch(IOException e) {
			e.printStackTrace();
			System.exit(0);
		}
		
		// perform check
		for (int id: m.getRowIds())
			if (m.getRow(id).size() != 1084) {
				System.out.println("Error reading genome scores");
				System.exit(1);
			}
		
		return m;
	}

	
	
	/**
	 * Parses a string and stores the tokens in a set.
	 * @param str - a string
	 * @return a HashSet containing the tokens
	 */
	private static Set<String> toSet(String str) {
		// perform error check
		if (str.length() < 1) {
			System.out.println("Error string argument is empty");
			System.exit(1);
		}
		
		Set<String> set = new HashSet<>();
		
		StringTokenizer st = new StringTokenizer(str, ",");
		if (st.countTokens() < 1) {
			System.out.println("Error parsing string: " + str);
			System.exit(1);
		}
		
		while (st.hasMoreTokens())
	         set.add(st.nextToken().trim());
		
		return set;
	}
	
	/**
	 * Copies the Map<Integer,Double> object's values into an array. The values 
	 * are sorted in ascending order by each value's corresponding key.
	 * @param map - a Map object
	 * @return an array containing the Map object's values
	 */
	private static double[] toArray(Map<Integer,Double> map) {
		// get the profile's ids
		Set<Integer> keys = map.keySet();
		
		// sort the keys
		SortedSet<Integer> ss = new TreeSet<Integer>();
		for (int k: keys)
			ss.add(k);
		
		// add the map's values (sorted by the each value's corresponding key)
		double[] values = new double[keys.size()];
		int index = 0;
		for(Iterator<Integer> iter = ss.iterator(); iter.hasNext(); ) {
			int k = iter.next();
			values[index] = map.get(k);
			index++;
		}
		
		return values;
	}
}
