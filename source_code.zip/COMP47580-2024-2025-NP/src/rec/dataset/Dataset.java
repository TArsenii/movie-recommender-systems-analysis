package rec.dataset;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import rec.util.Matrix;

public class Dataset {
	private Set<Integer> userIds; // stores all user ids
	private Set<Integer> itemIds; // stores all item ids
	private Matrix userTrainRatings; // stores training set ratings for all users
	private Matrix userValidationRatings; // stores validation set ratings for all users
	private Matrix userTestRatings; // stores test set ratings for all users
	private Matrix itemTrainRatings; // stores training set ratings for all items
	private Map<Integer,Item> items; // stores the data for all items
	private int maxItemPopularity; // the maximum item popularity (based on the number of ratings in the training set)
	private Set<String> datasetGenres; // stores all genres in the dataset
	
	/** 
	 * Constructs a Dataset object using the MovieLens Tag Genome Dataset 2021 dataset
	 * (https://grouplens.org/datasets/movielens/tag-genome-2021).
	 * @param userTrainRatings - training set ratings for all users
	 * @param userValidationRatings - validation set ratings for all users
	 * @param userTestRatings - test set ratings for all users
	 * @param itemTrainRatings - training set ratings for all items
	 * @param items - data for all items
	 */
	public Dataset(Matrix userTrainRatings, 
			Matrix userValidationRatings, 
			Matrix userTestRatings,
			Matrix itemTrainRatings, 
			Map<Integer,Item> items) {
		this.userTrainRatings = userTrainRatings;
		this.userValidationRatings = userValidationRatings;
		this.userTestRatings = userTestRatings;
		this.itemTrainRatings = itemTrainRatings;
		this.items = items;
		init();	
	}
	
	/**
	 * Returns all user ids in the training set.
	 * @return a HashSet containing all user ids
	 */
	public Set<Integer> getUserIds() {
		return userIds;
	}
	
	/**
	 * Returns all item ids in the training set.
	 * @return a HashSet containing all item ids
	 */
	public Set<Integer> getItemIds() {
		return itemIds;
	}
	
	/**
	 * Returns an item.
	 * @param id - the numeric id of the item
	 * @return an Item object
	 */
	public Item getItem(int id) {
		return items.get(id);
	}
	
	/**
	 * Returns all genres in the dataset.
	 * @return a HashSet containing all genres in the dataset 
	 */
	public Set<String> getDatasetGenres() {
		return datasetGenres;
	}
	
	/**
	 * Returns the training set ratings for the specified user.
	 * @param id - the numeric id of the user
	 * @return a HashMap containing the user's training set ratings
	 */
	public Map<Integer,Double> getUserTrainRatings(int id) {
		return userTrainRatings.getRow(id);
	}
	
	/**
	 * Returns the mean of the training set ratings for the specified user.
	 * @param id - the numeric id of the user
	 * @return the mean of the users's training set ratings
	 */
	public double getUserTrainRatingsMean(int id) {
		return userTrainRatings.getRowMean(id);
	}
	
	/**
	 * Returns the validation set ratings for the specified user.
	 * @param id - the numeric id of the user
	 * @return a HashMap containing the user's validation set ratings
	 */
	public Map<Integer,Double> getUserValidationRatings(int id) {
		return userValidationRatings.getRow(id);
	}
	
	/**
	 * Returns the validation set ratings for all users.
	 * @return a Matrix containing all users' validation set ratings
	 */
	public Matrix getUserValidationRatings() {
		return userValidationRatings;
	}
	
	/**
	 * Returns the test set ratings for the specified user.
	 * @param id - the numeric id of the user
	 * @return a HashMap containing the user's test set ratings
	 */
	public Map<Integer,Double> getUserTestRatings(int id) {
		return userTestRatings.getRow(id);
	}
	
	/**
	 * Returns the test set ratings for all users.
	 * @return a Matrix containing all users' test set ratings
	 */
	public Matrix getUserTestRatings() {
		return userTestRatings;
	}
	
	/**
	 * Returns the training set ratings for the specified item.
	 * @param id - the numeric id of the item
	 * @return a HashMap containing the item's training set ratings
	 */
	public Map<Integer,Double> getItemTrainRatings(int id) {
		return itemTrainRatings.getRow(id);
	}
	
	/**
	 * Returns the mean of the training set ratings for the specified item.
	 * @param id - the numeric id of the item
	 * @return the mean of the item's training set ratings
	 */
	public double getItemTrainRatingsMean(int id) {
		return itemTrainRatings.getRowMean(id);
	}
	
	/**
	 * Returns the maximum item popularity (based on the number of ratings in the training set).
	 * @return the maximum item popularity
	 */
	public int getMaxItemPopularity() {
		return maxItemPopularity;
	}
	
	/**
	 * This method:
	 * (i)   Stores all user ids in the training set in a HashSet
	 * (ii)  Stores all item ids in the training set in a HashSet
	 * (iii) Calculates the maximum item popularity based on the number of ratings each item has received
	 */
	private void init() {
		// store user ids
		userIds = new HashSet<>();
		for (int id: userTrainRatings.getRowIds())
			userIds.add(id);
		
		// store item ids
		itemIds = new HashSet<>();
		for (int id: itemTrainRatings.getRowIds())
			itemIds.add(id);
		
		// compute maximum item popularity
		int maxSize = -1;
		for (Integer id: items.keySet()) {
			int size = items.get(id).getTrainRatings().size();
			if (size > maxSize)
				maxSize = size;
		}
		maxItemPopularity = maxSize;
		
		// store dataset genres
		datasetGenres = new HashSet<>();
		for (int id: items.keySet())
			datasetGenres.addAll(items.get(id).getGenres());
	}
}
