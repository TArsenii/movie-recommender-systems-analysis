/**
 * This class represents a movie item
 */

package rec.dataset;

import java.util.Arrays;
import java.util.Map;
import java.util.Set;

public class Item {
	private int id; // the numeric id of the movie
	private String title; // the title of the movie
	private int year; // the release year of the movie
	private Set<String> directors; // the director(s) of the movie
	private Set<String> stars; // the actors starring in the movie
	private String imdbId; // the IMDB id of the movie
	private Set<String> genres; // the genres associated with the movie
	private double[] genomeScores; // the genome scores associated with the movie
	private Map<Integer,Double> trainRatings; // the training set ratings associated with the movie
	private double trainRatingsNorm; // the norm of the training set ratings
	
	/**
	 * constructor - creates a new Item object
	 * @param id - the movie's id
	 * @param title - the movie's title
	 * @param year - the movie's release year
	 * @param directors - the movie's director(s)
	 * @param stars - the movie's actors
	 * @param imdbId - the movie's IMDB id
	 * @param genres - the movie's genres
	 * @param genomeScores - the movie's genome scores
	 * @param trainRatings - the movie's training set ratings
	 */
	public Item(int id, String title, int year, Set<String> directors, Set<String> stars, 
			String imdbId, Set<String> genres, double[] genomeScores, Map<Integer,Double> trainRatings) {
		this.id = id;
		this.title = title;
		this.year = year;
		this.directors = directors;
		this.stars = stars;
		this.imdbId = imdbId;
		this.genres = genres;
		this.genomeScores = genomeScores;
		this.trainRatings = trainRatings;
		
		// calculate the norm of the training set ratings
		trainRatingsNorm = 0;
		for (double v: trainRatings.values())
			trainRatingsNorm += Math.pow(v, 2);
		trainRatingsNorm = Math.sqrt(trainRatingsNorm);
	}
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	
	/**
	 * @return the year
	 */
	public int getYear() {
		return year;
	}
	
	/**
	 * @return the director(s)
	 */
	public Set<String> getDirectors() {
		return directors;
	}
	
	/**
	 * @return the stars
	 */
	public Set<String> getStars() {
		return stars;
	}
	
	/**
	 * @return the IMDB id
	 */
	public String getImdbId() {
		return imdbId;
	}

	/**
	 * @return the genres
	 */
	public Set<String> getGenres() {
		return genres;
	}
	
	/**
	 * @return the genome scores
	 */
	public double[] getGenomeScores() {
		return genomeScores;
	}	
	
	/**
	 * @return the training set ratings
	 */
	public Map<Integer,Double> getTrainRatings() {
		return trainRatings;
	}
	
	/**
	 * @return the norm of the training set ratings
	 */
	public double getTrainRatingsNorm() {
		return trainRatingsNorm;
	}
	
	/**
	 * @return a string representation of this object
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(title + "\n");
		sb.append("   year: " + year + "\n");
		sb.append("   directors: " + directors.toString() + "\n");
		sb.append("   stars: " + stars.toString() + "\n");
		sb.append("   genres: " + genres.toString() + "\n");
		sb.append("   genomeScores: " + Arrays.toString(genomeScores) + "\n");
		sb.append("   trainRatings (number ratings): " + trainRatings.size() + "\n");
		sb.append("   id: " + id + "\n");
		sb.append("   imdbId: " + imdbId + "\n");
		return sb.toString();				
	}
}
