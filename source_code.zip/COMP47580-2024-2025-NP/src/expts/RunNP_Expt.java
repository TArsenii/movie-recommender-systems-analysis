/**
 * A class to execute various non-personalised recommender models.
 * Please do not edit this class.
 */

package expts;

import java.io.File;

import rec.dataset.Dataset;
import rec.dataset.Reader;
import rec.np.NPRecommender;
import rec.np.evaluator.NPEvaluator;
import rec.np.ranker.IncConfidenceRanker;
import rec.np.ranker.PopularityRanker;
import rec.np.ranker.GenomeCosineRanker;
import rec.np.ranker.GenreJaccardRanker;
import rec.np.ranker.Ranker;
import rec.np.ranker.RatingPearsonRanker;

public class RunNP_Expt {
	public static void main(String[] args) {	
		////////////////////////////////////
		// *** do not edit this class *** //
		////////////////////////////////////
		
		// set the paths and filenames of the item file, genome scores file, train file, validation file and test file ...
		String folder = "ml-2024-2025";
		String itemFile = folder + File.separator + "movie_data.txt";
		String itemGenomeScoresFile = folder + File.separator + "movie_genome_scores.txt";
		String trainFile = folder + File.separator + "train.txt";
		String validationFile = folder + File.separator + "validation.txt";
		String testFile = folder + File.separator + "test.txt";

		// read the dataset
		Reader reader = new Reader(itemFile, itemGenomeScoresFile, trainFile, validationFile, testFile);
		Dataset dataset = reader.getDataset();
		
		// set k - the number of recommendations to be made for each target item
		int k = 10;
		
		// set the threshold - an item is considered liked if its rating is >= threshold
		double threshold = 4.0; 

		// create an array of rankers
		Ranker[] rankers = {
				new PopularityRanker(),
				new GenreJaccardRanker(),
				new GenomeCosineRanker(),
				new RatingPearsonRanker(),
				new IncConfidenceRanker(threshold),
		};

		// display results for all models
		String[] labels = {
				"Popularity",
				"Genre Jaccard", 
				"Genome Cosine", 
				"Rating Pearson", 
				"Inc. Confidence",
		};
		
		System.out.println("k,Ranker,Relevance,Coverage,Rec. Coverage,Item Space Coverage,Category Coverage,Rec. Similarity,Rec. Popularity");
		
		for (int i = 0; i < rankers.length; i++) {
			// create a NPRecommender object using the current ranker (rankers[i])
			NPRecommender model = new NPRecommender(dataset, rankers[i]);
			model.fit();
			
			// create an NPEvaluator object using the current non-personalised recommender model
			NPEvaluator eval = new NPEvaluator(model, dataset, k, threshold);
			
			// display results for the current non-personalised recommender model
			System.out.printf("%d,%s,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f\n",
					k, labels[i], 
					eval.getRecommendationRelevance(),
					eval.getCoverage(),
					eval.getRecommendationCoverage(),
					eval.getItemSpaceCoverage(),
					eval.getCategoryCoverage(),
					eval.getRecommendationSimilarity(),
					eval.getRecommendationPopularity());
			
			// display dataset statistics
			if (i == rankers.length - 1) {
				double[] similarityStats = eval.getItemSimilarityStats();
				System.out.printf("\nmedian and IQR of all >0 pairwise item similarities: %.4f, %.4f\n", similarityStats[0], similarityStats[1]);
				
				double[] ratingStats = eval.getItemRatingStats();
				System.out.printf("\nmedian and IQR of mean item ratings: %.4f, %.4f\n", ratingStats[0], ratingStats[1]);
			
				double[] populatityStats = eval.getItemPopularityStats();
				System.out.printf("\nmedian and IQR of item popularity: %.4f, %.4f\n", populatityStats[0], populatityStats[1]);
			}
		}
	}
}
