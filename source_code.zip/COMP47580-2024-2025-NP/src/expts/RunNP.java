/**
 * A class to display the recommendations made by a non-personalised recommender model
 */

package expts;

import java.io.File;
import rec.dataset.Dataset;
import rec.dataset.Reader;
import rec.np.NPRecommender;
import rec.np.evaluator.NPEvaluator;
import rec.np.ranker.*;

public class RunNP {
	public static void main(String[] args) {		
		// set the paths and filenames of the item file, genome scores file, train file, validation file and test file ...
		String folder = "ml-2024-2025";
		String itemFile = folder + File.separator + "movie_data.txt";
		String itemGenomeScoresFile = folder + File.separator + "movie_genome_scores.txt";
		String trainFile = folder + File.separator + "train.txt";
		String validationFile = folder + File.separator + "validation.txt";
		String testFile = folder + File.separator + "test.txt";

		// read the dataset
		Reader reader = new Reader(itemFile, itemGenomeScoresFile, trainFile, validationFile, testFile);
		Dataset dataset = reader.getDataset();
		
		// configure the non-personalised recommender model
		Ranker ranker = new IncConfidenceRanker(4.0); // run this class using different rankers
		NPRecommender model = new NPRecommender(dataset, ranker);
		model.fit();
		
		// set k - the number of recommendations to be made for each target item
		int k = 3;
		
		// set the threshold - an item is considered liked if its rating is >= threshold
		double threshold = 4.0; 
		
		// display the top-k recommendations for 5 items
		NPEvaluator eval = new NPEvaluator(model, dataset, k, threshold);
		int[] itemIds = {89, 47, 68, 52, 756};
		for (int itemId: itemIds)
			eval.printRecs(itemId);
	}
}
